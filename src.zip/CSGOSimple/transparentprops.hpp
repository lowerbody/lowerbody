#include "valve_sdk\csgostructs.hpp"

#include "hooks.hpp"
#include "helpers/utils.hpp"
#include "options.hpp"

bool preformed_alpha_modulate = false;

class transparentprops
{
	class game_newmap_listener : public IGameEventListener2
	{
	public:
		void start()
		{
			g_GameEvents->AddListener(this, "game_newmap", false);
		}

		void stop()
		{
			g_GameEvents->RemoveListener(this);
		}

		void FireGameEvent(IGameEvent *event) override
		{
			transparentprops::singleton()->on_fire_event(event);
		}

		int GetEventDebugID(void) override
		{
			return EVENT_DEBUG_ID_INIT /*0x2A*/;
		}
	};
public:
	static transparentprops* singleton()
	{
		static transparentprops* instance = new transparentprops;
		return instance;
	}

	void initialize()
	{
		_listener.start();
	}

	void uninitialize()
	{
		_listener.stop();
	}

	void on_fire_event(IGameEvent* event)
	{
		if (!strcmp(event->GetName(), "game_newmap")) {
			preformed_alpha_modulate = false;
		}
	}

	void on_createmove()
	{
		static ConVar* r_drawspecificstaticprop = g_CVar->FindVar("r_drawspecificstaticprop");

		r_drawspecificstaticprop->SetValue(0);

		if (!g_LocalPlayer || !g_EngineClient->IsConnected() || !g_EngineClient->IsInGame())
			return;

		if (g_Options.aesthetics_transparent_props)
		{
			if (!preformed_alpha_modulate)
			{
				for (MaterialHandle_t i = g_MatSystem->FirstMaterial(); i != g_MatSystem->InvalidMaterial(); i = g_MatSystem->NextMaterial(i))
				{
					IMaterial* material = g_MatSystem->GetMaterial(i);

					if (!material || material->IsErrorMaterial())
						continue;

					if (strstr(material->GetTextureGroupName(), "StaticProp"))
						material->AlphaModulate(0.8f);

					preformed_alpha_modulate = true;
				}
			}
		}
		else
		{
			if (preformed_alpha_modulate)
			{
				for (MaterialHandle_t i = g_MatSystem->FirstMaterial(); i != g_MatSystem->InvalidMaterial(); i = g_MatSystem->NextMaterial(i))
				{
					IMaterial* material = g_MatSystem->GetMaterial(i);

					if (!material || material->IsErrorMaterial())
						continue;

					if (strstr(material->GetTextureGroupName(), "StaticProp"))
						material->AlphaModulate(1.f);

					preformed_alpha_modulate = false;
				}
			}
		}
	}
private:
	game_newmap_listener    _listener;
};