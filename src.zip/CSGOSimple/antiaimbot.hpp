#pragma once

#include "valve_sdk\csgostructs.hpp"

#include "helpers/utils.hpp"
#include "helpers\math.hpp"

#include "hooks.hpp"
#include "options.hpp"

#include "weapon_ids.hpp"

class C_BasePlayer;
class CUserCmd;

namespace AntiAimbot
{
	void OnCreateMove(CUserCmd* cmd, bool &bSendPacket);
}