#pragma once

class C_BasePlayer;
class CUserCmd;

namespace Bunnyhop
{
    void OnCreateMove(CUserCmd* cmd);
}