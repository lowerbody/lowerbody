#pragma once

class C_BasePlayer;
class CUserCmd;

namespace ClantagSpammer
{
	void OnCreateMove(CUserCmd* cmd);
}