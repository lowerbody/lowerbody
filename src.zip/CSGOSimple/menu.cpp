#include "Menu.hpp"
#define NOMINMAX
#include <Windows.h>
#include <chrono>

#include "valve_sdk/csgostructs.hpp"
#include "helpers/input.hpp"
#include "helpers/utils.hpp"

#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui/imgui_internal.h"
#include "imgui/directx9/imgui_impl_dx9.h"

#include "json.hpp"
#include "configuration.hpp"
#include "itemdefinitions.hpp"
#include "options.hpp"

static ConVar* cl_mouseenable = nullptr;

namespace ImGuiEx
{
	inline bool ColorButton(const char* label, Color* v)
	{
		auto clr = ImVec4{
			v->r() / 255.0f,
			v->g() / 255.0f,
			v->b() / 255.0f,
			v->a() / 255.0f
		};

		if (ImGui::ColorEdit4(label, &clr.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel)) {
			v->SetColor(clr.x, clr.y, clr.z, clr.w);
			return true;
		}

		return false;
	}
}

void ShowHelpMarker(const char* desc)
{
	ImGui::TextDisabled("(?)");
	if (ImGui::IsItemHovered())
	{
		ImGui::BeginTooltip();
		ImGui::PushTextWrapPos(450.0f);
		ImGui::TextUnformatted(desc);
		ImGui::PopTextWrapPos();
		ImGui::EndTooltip();
	}
}

void Menu::Initialize()
{
    _visible = true;

    cl_mouseenable = g_CVar->FindVar("cl_mouseenable");

    ImGui_ImplDX9_Init(InputSys::Get().GetMainWindow(), g_D3DDevice9);
}

void Menu::Shutdown()
{
    ImGui_ImplDX9_Shutdown();
    cl_mouseenable->SetValue(true);
}

void Menu::OnDeviceLost()
{
    ImGui_ImplDX9_InvalidateDeviceObjects();
}

void Menu::OnDeviceReset()
{
    ImGui_ImplDX9_CreateDeviceObjects();
}

void Menu::Render()
{
    if (!_visible)
        return;

    ImGui_ImplDX9_NewFrame();

    ImGui::GetIO().MouseDrawCursor = _visible;

	ImGui::SetNextWindowSize(ImVec2(625, 525), ImGuiCond_FirstUseEver);
	if (ImGui::Begin("lowerbody", NULL, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse))
	{
		static int page;

		const char* tabs[] = {
			"Rage",
			"Legit",
			"Visual",
			"Miscellaneous",
			"Skins"
		};

		for (int i = 0; i < ARRAYSIZE(tabs); i++)
		{
			if (ImGui::Button(tabs[i], ImVec2(ImGui::GetWindowSize().x / ARRAYSIZE(tabs) - 10, 30)))
				page = i;

			if (i < ARRAYSIZE(tabs) - 1)
				ImGui::SameLine();
		}

		ImGui::Separator();

		static char* hitboxes[] = { "Head", "Neck", "Chest", "Pelvis" };
		static char* pitches[] = { "None", "Zero", "Up", "Down" };
		static char* breakable_yaws[] = { "None", "Backwards", "Left", "Right", "Left Random", "Right Random", "Left Half Spin", "Right Half Spin", "Automatic", "Automatic Random", "Automatic Half Spin", "Local View", "Spin", "Lower Body" };
		static char* yaws[] = { "None", "Backwards", "Left", "Right", "Left Random", "Right Random", "Left Half Spin", "Right Half Spin", "Automatic", "Automatic Random", "Automatic Half Spin", "Local View", "Spin", "Inverse" };

		ImGui::BeginChild("");
		switch (page)
		{
		case 0:
			if (ImGui::TreeNode("Aimbot"))
			{
				ImGui::Checkbox("Enabled", &g_Options.ragebot_enabled);
				ImGui::Checkbox("Teammates", &g_Options.ragebot_teammates);
				ImGui::Checkbox("Auto shoot", &g_Options.ragebot_auto_shoot);
				ImGui::Checkbox("Auto scope", &g_Options.ragebot_auto_scope);
				ImGui::Checkbox("Auto wall", &g_Options.ragebot_auto_wall);
				ImGui::Checkbox("Hit scan", &g_Options.ragebot_hit_scan);
				ImGui::Combo("Hitbox", &g_Options.ragebot_hitbox, hitboxes, IM_ARRAYSIZE(hitboxes));
				ImGui::SliderInt("Field of view", &g_Options.ragebot_fov, 1, 360, "%.0f degrees");
				ImGui::SliderInt("Minimum damage", &g_Options.ragebot_minimum_damage, 1, 100, "%.0f health");
				ImGui::SliderInt("Hit chance", &g_Options.ragebot_hit_chance, 1, 100, "%.0f percent");
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Anti Aimbot"))
			{
				ImGui::Checkbox("Enabled", &g_Options.anti_aimbot_enabled);
				ImGui::Combo("Pitch", &g_Options.anti_aimbot_pitch, pitches, IM_ARRAYSIZE(pitches));
				ImGui::Combo("Yaw", &g_Options.anti_aimbot_yaw, breakable_yaws, IM_ARRAYSIZE(breakable_yaws));
				ImGui::SliderInt("Yaw offset", &g_Options.anti_aimbot_yaw_offset, -180, 180, "%.0f degrees");
				ImGui::Combo("Yaw while running", &g_Options.anti_aimbot_yaw_while_running, yaws, IM_ARRAYSIZE(yaws));
				ImGui::SliderInt("Yaw while running offset", &g_Options.anti_aimbot_yaw_while_running_offset, -180, 180, "%.0f degrees");
				ImGui::Combo("Fake yaw", &g_Options.anti_aimbot_fake_yaw, yaws, IM_ARRAYSIZE(yaws));
				ImGui::SliderInt("Fake yaw offset", &g_Options.anti_aimbot_fake_yaw_offset, -180, 180, "%.0f degrees");
				ImGui::SliderInt("Spin speed", &g_Options.anti_aimbot_spin_speed, 1, 100, "%.0f ap/t");
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Corrections"))
			{
				ImGui::Checkbox("Fake yaw correction", &g_Options.corrections_fake_yaw_correction); ImGui::SameLine(); ShowHelpMarker("Attempt to remove faked yaw angles.");
				ImGui::TreePop();
			}
			break;
		case 1:
			if (ImGui::TreeNode("Pistol"))
			{
				ImGui::Checkbox("Enabled", &g_Options.pistol_enabled);
				ImGui::Checkbox("Teammates", &g_Options.pistol_teammates);
				ImGui::Checkbox("Recoil control system", &g_Options.pistol_rcs);
				ImGui::Combo("Hitbox", &g_Options.pistol_hitbox, hitboxes, IM_ARRAYSIZE(hitboxes));
				ImGui::SliderInt("Field of view", &g_Options.pistol_fov, 1, 360, "%.0f degrees");
				ImGui::SliderInt("Smooth pitch", &g_Options.pistol_smooth_x, 1, 100);
				ImGui::SliderInt("Smooth yaw", &g_Options.pistol_smooth_y, 1, 100);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Shotgun"))
			{
				ImGui::Checkbox("Enabled", &g_Options.shotgun_enabled);
				ImGui::Checkbox("Teammates", &g_Options.shotgun_teammates);
				ImGui::Checkbox("Recoil control system", &g_Options.shotgun_rcs);
				ImGui::Combo("Hitbox", &g_Options.shotgun_hitbox, hitboxes, IM_ARRAYSIZE(hitboxes));
				ImGui::SliderInt("Field of view", &g_Options.shotgun_fov, 1, 360, "%.0f degrees");
				ImGui::SliderInt("Smooth pitch", &g_Options.shotgun_smooth_x, 1, 100);
				ImGui::SliderInt("Smooth yaw", &g_Options.shotgun_smooth_y, 1, 100);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("SMG"))
			{
				ImGui::Checkbox("Enabled", &g_Options.smg_enabled);
				ImGui::Checkbox("Teammates", &g_Options.smg_teammates);
				ImGui::Checkbox("Recoil control system", &g_Options.smg_rcs);
				ImGui::Combo("Hitbox", &g_Options.smg_hitbox, hitboxes, IM_ARRAYSIZE(hitboxes));
				ImGui::SliderInt("Field of view", &g_Options.smg_fov, 1, 360, "%.0f degrees");
				ImGui::SliderInt("Smooth pitch", &g_Options.smg_smooth_x, 1, 100);
				ImGui::SliderInt("Smooth yaw", &g_Options.smg_smooth_y, 1, 100);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Rifle"))
			{
				ImGui::Checkbox("Enabled", &g_Options.rifle_enabled);
				ImGui::Checkbox("Teammates", &g_Options.rifle_teammates);
				ImGui::Checkbox("Recoil control system", &g_Options.rifle_rcs);
				ImGui::Combo("Hitbox", &g_Options.rifle_hitbox, hitboxes, IM_ARRAYSIZE(hitboxes));
				ImGui::SliderInt("Field of view", &g_Options.rifle_fov, 1, 360, "%.0f degrees");
				ImGui::SliderInt("Smooth pitch", &g_Options.rifle_smooth_x, 1, 100);
				ImGui::SliderInt("Smooth yaw", &g_Options.rifle_smooth_y, 1, 100);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Sniper"))
			{
				ImGui::Checkbox("Enabled", &g_Options.sniper_enabled);
				ImGui::Checkbox("Teammates", &g_Options.sniper_teammates);
				ImGui::Checkbox("Recoil control system", &g_Options.sniper_rcs);
				ImGui::Combo("Hitbox", &g_Options.sniper_hitbox, hitboxes, IM_ARRAYSIZE(hitboxes));
				ImGui::SliderInt("Field of view", &g_Options.sniper_fov, 1, 360, "%.0f degrees");
				ImGui::SliderInt("Smooth pitch", &g_Options.sniper_smooth_x, 1, 100);
				ImGui::SliderInt("Smooth yaw", &g_Options.sniper_smooth_y, 1, 100);
				ImGui::TreePop();
			}
			break;
		case 2:
			if (ImGui::TreeNode("ESP"))
			{
				ImGui::Checkbox("Teammates", &g_Options.esp_teammates);
				ImGui::Checkbox("Bounding box", &g_Options.esp_bounding_box); ImGui::SameLine(); ImGuiEx::ColorButton("Bounding box", &g_Options.color_esp_bounding_box);
				ImGui::Checkbox("Name", &g_Options.esp_name);
				ImGui::Checkbox("Flags", &g_Options.esp_flags);
				ImGui::Checkbox("Health", &g_Options.esp_health);
				ImGui::Checkbox("Weapon", &g_Options.esp_weapon);
				ImGui::Checkbox("Ammo", &g_Options.esp_ammo);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Glow"))
			{
				ImGui::Checkbox("Teammates", &g_Options.glow_teammates);
				ImGui::Checkbox("Players", &g_Options.glow_players); ImGui::SameLine(); ImGuiEx::ColorButton("Players", &g_Options.color_glow_players);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Colored Models"))
			{
				ImGui::Checkbox("Teammates", &g_Options.colored_models_teammates);
				ImGui::Checkbox("Players", &g_Options.colored_models_players); ImGui::SameLine(); ImGuiEx::ColorButton("Players", &g_Options.color_colored_models_players);
				ImGui::Checkbox("Players (behind walls)", &g_Options.colored_models_players_behind_walls); ImGui::SameLine(); ImGuiEx::ColorButton("Players (behind walls)", &g_Options.color_colored_models_players_behind_walls);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Removals"))
			{
				ImGui::Checkbox("Remove scope", &g_Options.removals_remove_scope);
				ImGui::Checkbox("Remove flashbang effects", &g_Options.removals_remove_flashbang_effects);
				ImGui::Checkbox("Remove smoke grenades", &g_Options.removals_remove_smoke_grenades);
				ImGui::Checkbox("Remove visual recoil", &g_Options.removals_remove_visual_recoil);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Aesthetic##visuals"))
			{
				ImGui::Checkbox("Night mode", &g_Options.aesthetics_night_mode);
				ImGui::Checkbox("Transparent props", &g_Options.aesthetics_transparent_props);
				ImGui::Checkbox("Bullet tracers", &g_Options.aesthetics_bullet_tracers); ImGui::SameLine(); ImGuiEx::ColorButton("Bullet tracers", &g_Options.color_bullet_tracers);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Information##visuals"))
			{
				ImGui::Checkbox("Third person", &g_Options.information_third_person);
				ImGui::Checkbox("Visualize spread", &g_Options.information_visualize_spread); ImGui::SameLine(); ImGuiEx::ColorButton("Visualize spread", &g_Options.color_visualize_spread);
				ImGui::Checkbox("Visualize angles", &g_Options.information_visualize_angles);
				ImGui::Checkbox("Indicators", &g_Options.information_indicators);
				ImGui::Checkbox("Event logs", &g_Options.information_event_logs);
				ImGui::TreePop();
			}
			break;
		case 3:
			if (ImGui::TreeNode("Movement"))
			{
				ImGui::Checkbox("Bunnyhop", &g_Options.movement_bunnyhop);
				ImGui::Checkbox("Auto strafe", &g_Options.movement_auto_strafe);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Aesthetic##miscellaneous"))
			{
				if (ImGui::Checkbox("Clantag spammer", &g_Options.aesthetics_clantag_spammer))
					Utils::SetClantag("");
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Information##miscellaneous"))
			{
				ImGui::Checkbox("Hit markers", &g_Options.information_hit_markers);
				ImGui::Checkbox("Rank revealer", &g_Options.information_rank_revealer);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Automation"))
			{
				ImGui::Checkbox("Auto accept", &g_Options.automation_auto_accept);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Exploits"))
			{
				ImGui::Checkbox("Backtrack moving targets", &g_Options.exploits_backtrack_moving_targets);
				ImGui::SliderInt("Backtrack ticks", &g_Options.exploits_backtrack_ticks, 1, 16, "%.0f ticks");
				ImGui::TreePop();
			}
			break;
		case 4:
			if (ImGui::TreeNode("Items")) {
				// Loop through the game item list.
				for (const auto& item : ItemDefinitionIndex) {
					// Get the configuration for the current item.
					EconomyItem_t& weapon = config.GetWeaponConfiguration(item.first);

					// Ensure that our settings will be used.
					if (!weapon.is_valid)
						weapon.is_valid = true;

					// Hide place holder items.
					if (strcmp(item.second.entity_name, "WEAPON_KNIFE_BAYONET") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_FLIP") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_GUT") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_KARAMBIT") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_M9_BAYONET") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_TACTICAL") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_FALCHION") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_SURVIVAL_BOWIE") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_BUTTERFLY") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_PUSH") == 0)
						continue;

					// Create a new node in the tree for this item.
					if (ImGui::TreeNode(item.second.display_name)) {
						// Add input forms to edit values for this item.
						ImGui::Text("Paint kit");
						if (ImGui::InputInt(std::string("##paint_kit").append(item.second.entity_name).c_str(), &weapon.fallback_paint_kit))
							g_ClientState->ForceFullUpdate();
						ImGui::Spacing();

						ImGui::Text("Custom seed");
						if (ImGui::InputInt(std::string("##seed").append(item.second.entity_name).c_str(), &weapon.fallback_seed))
							g_ClientState->ForceFullUpdate();
						ImGui::Spacing();

						ImGui::Text("Item quality");
						if (ImGui::InputInt(std::string("##quality").append(item.second.entity_name).c_str(), &weapon.entity_quality))
							g_ClientState->ForceFullUpdate();
						ImGui::Spacing();

						// Check if they should be able to change the item's index.
						if (strcmp(item.second.entity_name, "WEAPON_KNIFE") == 0 || strcmp(item.second.entity_name, "WEAPON_KNIFE_T") == 0) {
							ImGui::Text("Override item index");
							if (ImGui::InputInt(std::string("##override_item").append(item.second.entity_name).c_str(), &weapon.item_definition_index))
								g_ClientState->ForceFullUpdate();
							ImGui::Spacing();
						}

						ImGui::Text("Item wear");
						if (ImGui::SliderFloat(std::string("##wear").append(item.second.entity_name).c_str(), &weapon.fallback_wear, 0.00001f, 2.0f, "(%.5f)"))
							g_ClientState->ForceFullUpdate();
						ImGui::Spacing();

						if (ImGui::Button("Reset")) {
							// Reset all settings for this weapon to default.
							weapon.Reset();

							// Perform a full update.
							g_ClientState->ForceFullUpdate();
						}

						ImGui::SameLine();

						if (ImGui::Button("Apply")) {
							// Perform a full update.
							g_ClientState->ForceFullUpdate();
						}

						ImGui::TreePop();
					}
				}

				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Presets")) {
				// Get the configuration file extension.
				static std::string extension = config.GetConfigExtension();

				// Get a list of configuration files in the working directory.
				static std::vector<std::string> presets = config.GetPresets();

				// Show a text box for creating new presets.
				static char preset_filename[64];
				ImGui::Text("Preset filename");
				ImGui::InputText("##current_filename", preset_filename, 64);
				ImGui::SameLine();

				if (ImGui::Button("New")) {
					// Append the file extension if the user did not specify it.
					std::string filename(preset_filename);

					if (!std::equal(extension.rbegin(), extension.rend(), filename.rbegin()))
						filename = filename.append(extension);

					// Save the new preset to disk.
					config.SavePreset(filename);

					// Refresh the list of presets.
					presets = config.GetPresets();
				}

				// Whether we should clear other item settings when loading a preset.
				static bool reset_on_load = false;
				ImGui::Checkbox("Reset settings on load", &reset_on_load);

				if (presets.size() >= 1) {
					for (const std::string& preset : presets) {
						// Display the filename of this preset.
						ImGui::AlignFirstTextHeightToWidgets();
						ImGui::BulletText(preset.c_str());
						ImGui::SameLine();

						if (ImGui::Button(std::string("Save##").append(preset).c_str())) {
							// Overwrite this file with current item settings.
							config.SavePreset(preset);
						}

						ImGui::SameLine();

						if (ImGui::Button(std::string("Load##").append(preset).c_str())) {
							// Load current settings from this file.
							config.LoadPreset(preset, reset_on_load);

							// Perform a full update.
							g_ClientState->ForceFullUpdate();
						}

						ImGui::SameLine();

						if (ImGui::Button(std::string("Delete##").append(preset).c_str()) && config.RemovePreset(preset.c_str())) {
							// Attempt to delete the preset file from disk.
							presets = config.GetPresets();
						}

						ImGui::Spacing();
					}
				}
				else {
					// Show default text when no presets exist.
					ImGui::TextWrapped("No presets found. You can create a preset by entering a name above and pressing the 'New' button.");
				}

				if (ImGui::Button("Refresh preset list")) {
					// Check the folder again for more presets.
					presets = config.GetPresets();
				}

				ImGui::SameLine();

				if (ImGui::Button("Reset all settings")) {
					// Reset all user settings.
					config.ResetWeaponConfiguration();

					// Perform a full update.
					g_ClientState->ForceFullUpdate();
				}
			}
			ImGui::TreePop();
			break;
		}
		ImGui::EndChild();
	}

	ImGui::End();

    ImGui::Render();
}

void Menu::Show()
{
    _visible = true;
    cl_mouseenable->SetValue(false);
}

void Menu::Hide()
{
    _visible = false;
    cl_mouseenable->SetValue(true);
}

void Menu::Toggle()
{
    _visible = !_visible;
    cl_mouseenable->SetValue(!_visible);
}