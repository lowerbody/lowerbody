#include "weapon_ids.hpp"

CWeaponIDs g_WeaponIDs;
