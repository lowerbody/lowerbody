#include "clantagspammer.hpp"
#include "valve_sdk/csgostructs.hpp"
#include "helpers/utils.hpp"

void ClantagSpammer::OnCreateMove(CUserCmd* cmd)
{
	if (!g_LocalPlayer)
		return;

	int time = (float) g_GlobalVars->interval_per_tick * g_LocalPlayer->m_nTickBase() * 2.5;

	switch (time % 22) {
	case 0: Utils::SetClantag("            l"); break;
	case 1: Utils::SetClantag("           lo"); break;
	case 2: Utils::SetClantag("          low"); break;
	case 3: Utils::SetClantag("         lowe"); break;
	case 4: Utils::SetClantag("        lower"); break;
	case 5: Utils::SetClantag("       lowerb"); break;
	case 6: Utils::SetClantag("      lowerbo"); break;
	case 7: Utils::SetClantag("     lowerbod"); break;
	case 8: Utils::SetClantag("    lowerbody"); break;
	case 9: Utils::SetClantag("   lowerbody "); break;
	case 10: Utils::SetClantag("  lowerbody  "); break;
	case 11: Utils::SetClantag(" lowerbody   "); break;
	case 12: Utils::SetClantag("lowerbody    "); break;
	case 13: Utils::SetClantag("owerbody     "); break;
	case 14: Utils::SetClantag("werbody      "); break;
	case 15: Utils::SetClantag("erbody       "); break;
	case 16: Utils::SetClantag("rbody        "); break;
	case 17: Utils::SetClantag("body         "); break;
	case 18: Utils::SetClantag("ody          "); break;
	case 19: Utils::SetClantag("dy           "); break;
	case 20: Utils::SetClantag("y            "); break;
	case 21: Utils::SetClantag("             "); break;
	}
}