#define NOMINMAX
#include <Windows.h>

#include "valve_sdk/sdk.hpp"
#include "valve_sdk/csgostructs.hpp"
#include "helpers/utils.hpp"
#include "helpers/input.hpp"

#include "hooks.hpp"
#include "menu.hpp"
#include "configuration.hpp"
#include "options.hpp"

HINSTANCE dll_instance;
Configuration config;

DWORD WINAPI OnDllAttach(LPVOID base)
{
    if (Utils::WaitForModules(10000, { L"client.dll", L"engine.dll", L"shaderapidx9.dll" }) == WAIT_TIMEOUT) {
        return FALSE;
    }

    try {
        Interfaces::Initialize();

        NetvarSys::Get().Initialize();

        InputSys::Get().Initialize();
        Menu::Get().Initialize();

        Hooks::Initialize();

		config.SetBaseFolder(static_cast<HMODULE>(dll_instance));

        InputSys::Get().RegisterHotkey(VK_INSERT, [base]() {
            Menu::Get().Toggle();
        });
    } catch(const std::exception& ex) {
        FreeLibraryAndExitThread(static_cast<HMODULE>(base), 1);
    }
}

BOOL WINAPI OnDllDetach()
{
    Hooks::Shutdown();

    Menu::Get().Shutdown();
    return TRUE;
}

BOOL WINAPI DllMain(
    _In_      HINSTANCE hinstDll,
    _In_      DWORD     fdwReason,
    _In_opt_  LPVOID    lpvReserved
)
{
    switch(fdwReason) {
        case DLL_PROCESS_ATTACH:
            DisableThreadLibraryCalls(hinstDll);
            CreateThread(nullptr, 0, OnDllAttach, hinstDll, 0, nullptr);
			dll_instance = hinstDll;
            return TRUE;
        case DLL_PROCESS_DETACH:
            if(lpvReserved == nullptr)
                return OnDllDetach();
            return TRUE;
        default:
            return TRUE;
    }
}
