#pragma once

#include <string>
#include "valve_sdk/Misc/Color.hpp"

#define OPTION(type, var, val) type var = val

class Config
{
public:
	//
	// RAGEBOT
	//
	OPTION(bool, ragebot_enabled, false);
	OPTION(bool, ragebot_teammates, false);
	OPTION(bool, ragebot_auto_wall, false);
	OPTION(bool, ragebot_auto_shoot, false);
	OPTION(bool, ragebot_auto_scope, false);
	OPTION(bool, ragebot_hit_scan, false);
	OPTION(int, ragebot_hitbox, 0);
	OPTION(int, ragebot_fov, 1);
	OPTION(int, ragebot_minimum_damage, 1);
	OPTION(int, ragebot_hit_chance, 1);

	//
	// ANTI AIMBOT
	//
	OPTION(bool, anti_aimbot_enabled, false);
	OPTION(int, anti_aimbot_pitch, 0);
	OPTION(int, anti_aimbot_yaw, 0);
	OPTION(int, anti_aimbot_yaw_offset, 0);
	OPTION(int, anti_aimbot_yaw_while_running, 0);
	OPTION(int, anti_aimbot_yaw_while_running_offset, 0);
	OPTION(int, anti_aimbot_fake_yaw, 0);
	OPTION(int, anti_aimbot_fake_yaw_offset, 0);
	OPTION(int, anti_aimbot_spin_speed, 1);

	//
	// CORRECTIONS
	//
	OPTION(bool, corrections_fake_yaw_correction, false);

	//
	// LEGITBOT
	//
	OPTION(bool, pistol_enabled, false);
	OPTION(bool, pistol_teammates, false);
	OPTION(bool, pistol_rcs, false);
	OPTION(int, pistol_hitbox, 0);
	OPTION(int, pistol_fov, 1);
	OPTION(int, pistol_smooth_x, 1);
	OPTION(int, pistol_smooth_y, 1);

	OPTION(bool, shotgun_enabled, false);
	OPTION(bool, shotgun_teammates, false);
	OPTION(bool, shotgun_rcs, false);
	OPTION(int, shotgun_hitbox, 0);
	OPTION(int, shotgun_fov, 1);
	OPTION(int, shotgun_smooth_x, 1);
	OPTION(int, shotgun_smooth_y, 1);

	OPTION(bool, smg_enabled, false);
	OPTION(bool, smg_teammates, false);
	OPTION(bool, smg_rcs, false);
	OPTION(int, smg_hitbox, 0);
	OPTION(int, smg_fov, 1);
	OPTION(int, smg_smooth_x, 1);
	OPTION(int, smg_smooth_y, 1);

	OPTION(bool, rifle_enabled, false);
	OPTION(bool, rifle_teammates, false);
	OPTION(bool, rifle_rcs, false);
	OPTION(int, rifle_hitbox, 0);
	OPTION(int, rifle_fov, 1);
	OPTION(int, rifle_smooth_x, 1);
	OPTION(int, rifle_smooth_y, 1);

	OPTION(bool, sniper_enabled, false);
	OPTION(bool, sniper_teammates, false);
	OPTION(bool, sniper_rcs, false);
	OPTION(int, sniper_hitbox, 0);
	OPTION(int, sniper_fov, 1);
	OPTION(int, sniper_smooth_x, 1);
	OPTION(int, sniper_smooth_y, 1);

    // 
    // ESP
    //
	OPTION(bool, esp_teammates, false);
	OPTION(bool, esp_bounding_box, false);
	OPTION(bool, esp_name, false);
	OPTION(bool, esp_flags, false);
	OPTION(bool, esp_health, false);
	OPTION(bool, esp_weapon, false);
	OPTION(bool, esp_ammo, false);

	OPTION(Color, color_esp_bounding_box, Color(255, 255, 255));

    // 
    // GLOW
    // 
	OPTION(bool, glow_teammates, false);
    OPTION(bool, glow_players, false);

	OPTION(Color, color_glow_players, Color(157, 206, 63));
	
	// 
	// COLORED MODELS
	// 
	OPTION(bool, colored_models_teammates, false);
	OPTION(bool, colored_models_players, false);
	OPTION(bool, colored_models_players_behind_walls, false);

	OPTION(Color, color_colored_models_players, Color(157, 206, 63));
	OPTION(Color, color_colored_models_players_behind_walls, Color(66, 126, 186));

	//
	// REMOVALS
	//
	OPTION(bool, removals_remove_scope, false);
	OPTION(bool, removals_remove_flashbang_effects, false);
	OPTION(bool, removals_remove_smoke_grenades, false);
	OPTION(bool, removals_remove_visual_recoil, false);

	//
	// AESTHETICS
	//
	OPTION(bool, aesthetics_night_mode, false);
	OPTION(bool, aesthetics_transparent_props, false);
	OPTION(bool, aesthetics_bullet_tracers, false);

	OPTION(Color, color_bullet_tracers, Color(255, 0, 255, 255));

	//
	// INFORMATION
	//
	OPTION(bool, information_third_person, false);
	OPTION(bool, information_indicators, false);
	OPTION(bool, information_visualize_spread, false);
	OPTION(bool, information_visualize_angles, false);
	OPTION(bool, information_event_logs, false);

	OPTION(Color, color_visualize_spread, Color(25, 25, 25, 125));

    //
    // MOVEMENT
    //
    OPTION(bool, movement_bunnyhop, false);
	OPTION(bool, movement_auto_strafe, false);

	//
	// INFORMATION (misc)
	//
	OPTION(bool, information_hit_markers, false);
	OPTION(bool, information_rank_revealer, false);

	//
	// AESTHETICS (misc)
	//
	OPTION(bool, aesthetics_clantag_spammer, false);

	//
	// AUTOMATION
	//
	OPTION(bool, automation_auto_accept, false);

	//
	// EXPLOITS
	//
	OPTION(bool, exploits_backtrack_moving_targets, false);
	OPTION(int, exploits_backtrack_ticks, 1);
};

extern Config g_Options;
extern bool   g_Unload;
