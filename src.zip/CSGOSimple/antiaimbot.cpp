#include "antiaimbot.hpp"

float GetBestHeadAngle(C_BasePlayer* player, float yaw)
{
	float Back, Right, Left;

	Vector src3D, dst3D, forward, right, up, src, dst;
	trace_t tr;
	Ray_t backray, rightray, leftray;
	CTraceFilter filter;

	QAngle angles;
	g_EngineClient->GetViewAngles(angles);
	angles.pitch = 0.f;

	Math::AngleVectors(angles, forward, right, up);

	filter.pSkip = player;
	src3D = player->GetEyePos();
	dst3D = src3D + (forward * 384.f);

	backray.Init(src3D, dst3D);
	g_EngineTrace->TraceRay(backray, MASK_SHOT, &filter, &tr);
	Back = (tr.endpos - tr.startpos).Length();

	rightray.Init(src3D + right * 35.f, dst3D + right * 35.f);
	g_EngineTrace->TraceRay(rightray, MASK_SHOT, &filter, &tr);
	Right = (tr.endpos - tr.startpos).Length();

	leftray.Init(src3D - right * 35.f, dst3D - right * 35.f);
	g_EngineTrace->TraceRay(leftray, MASK_SHOT, &filter, &tr);
	Left = (tr.endpos - tr.startpos).Length();

	if (Left > Right)
		return (yaw - 90.f);
	else if (Right > Left)
		return (yaw + 90.f);
	else if (Back > Right || Back > Left)
		return (yaw - 180.f);

	return 0;
}

float next_lby_update;
float old_lby;

float GetCurTime(CUserCmd* ucmd) {
	static int g_tick = 0;
	static CUserCmd* g_pLastCmd = nullptr;
	if (!g_pLastCmd || g_pLastCmd->hasbeenpredicted) {
		g_tick = g_LocalPlayer->m_nTickBase();
	}
	else {
		// Required because prediction only runs on frames, not ticks
		// So if your framerate goes below tickrate, m_nTickBase won't update every tick
		++g_tick;
	}
	g_pLastCmd = ucmd;
	float curtime = g_tick * g_GlobalVars->interval_per_tick;
	return curtime;
}

bool lby_updated(CUserCmd* cmd)
{
	// fuck pastes lool

	return false;
}

void AntiAimbot::OnCreateMove(CUserCmd* cmd, bool &bSendPacket)
{
	static int choked = -1;

	static QAngle angles;
	static float last_real;

	if (!g_LocalPlayer || !g_LocalPlayer->IsAlive() || !g_LocalPlayer->m_hActiveWeapon() || cmd->buttons & IN_USE || cmd->buttons & IN_ATTACK || g_LocalPlayer->GetMoveType() == MOVETYPE_LADDER || g_LocalPlayer->GetMoveType() == MOVETYPE_NOCLIP)
		return;

	if (g_WeaponIDs.IsGrenade(g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex()))
	{
		if (g_LocalPlayer->m_hActiveWeapon()->m_fThrowTime() > 0.f)
			return;
	}

	switch (g_Options.anti_aimbot_pitch)
	{
	case 0: break; // none
	case 1: cmd->viewangles.pitch = 0.f; break; // zero
	case 2: cmd->viewangles.pitch = -89.f; break; // up
	case 3: cmd->viewangles.pitch = 89.f; break; // down
	}

	choked++;

	if (choked < 1)
	{
		bSendPacket = false;

		if (g_LocalPlayer->m_vecVelocity().Length2D() > 1.f)
		{
			// running

			switch (g_Options.anti_aimbot_yaw_while_running)
			{
			case 0: break; // none
			case 1: cmd->viewangles.yaw -= 180.f; break; // backwards
			case 2: cmd->viewangles.yaw += 90.f; break; // left
			case 3: cmd->viewangles.yaw -= 90.f; break; // right
			case 4: cmd->viewangles.yaw += 90.f + rand() % (64 - -64 + 1) + -64; break; // left random
			case 5: cmd->viewangles.yaw -= 90.f + rand() % (64 - -64 + 1) + -64; break; // right random
			case 6:
				static float lhs_yaw;

				lhs_yaw += 5;

				if (lhs_yaw > 90) {
					lhs_yaw = -90;
				}

				cmd->viewangles.yaw += 90.f + lhs_yaw;
				break; // left half spin
			case 7:
				static float rhs_yaw;

				rhs_yaw += 5;

				if (rhs_yaw > 90) {
					rhs_yaw = -90;
				}

				cmd->viewangles.yaw -= 90.f + rhs_yaw;
				break; // right half spin
			case 8:
				g_EngineClient->GetViewAngles(angles);

				cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw);
				break; // automatic
			case 9:
				g_EngineClient->GetViewAngles(angles);

				cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw) + rand() % (64 - -64 + 1) + -64;
				break; // automatic random
			case 10:
				static float ahs_yaw;

				ahs_yaw += 5;

				if (ahs_yaw > 90) {
					ahs_yaw = -90;
				}

				cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw) + ahs_yaw;
				break; // automatic half spin
			case 11:
				g_EngineClient->GetViewAngles(angles);

				cmd->viewangles.yaw = angles.yaw;
				break; // local view
			case 12:
				static float s_yaw;

				s_yaw += g_Options.anti_aimbot_spin_speed;

				if (s_yaw > 180) {
					s_yaw = -180;
				}

				cmd->viewangles.yaw = s_yaw;
				break; // spin
			}

			cmd->viewangles.yaw += g_Options.anti_aimbot_yaw_while_running_offset;
		}
		else
		{
			// standing

			switch (g_Options.anti_aimbot_yaw)
			{
			case 0: break; // none
			case 1: cmd->viewangles.yaw -= 180.f; break; // backwards
			case 2: cmd->viewangles.yaw += 90.f; break; // left
			case 3: cmd->viewangles.yaw -= 90.f; break; // right
			case 4: cmd->viewangles.yaw += 90.f + rand() % (64 - -64 + 1) + -64; break; // left random
			case 5: cmd->viewangles.yaw -= 90.f + rand() % (64 - -64 + 1) + -64; break; // right random
			case 6:
				static float lhs_yaw;

				lhs_yaw += 5;

				if (lhs_yaw > 90) {
					lhs_yaw = -90;
				}

				cmd->viewangles.yaw += 90.f + lhs_yaw;
				break; // left half spin
			case 7:
				static float rhs_yaw;

				rhs_yaw += 5;

				if (rhs_yaw > 90) {
					rhs_yaw = -90;
				}

				cmd->viewangles.yaw -= 90.f + rhs_yaw;
				break; // right half spin
			case 8:
				g_EngineClient->GetViewAngles(angles);

				cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw);
				break; // automatic
			case 9:
				g_EngineClient->GetViewAngles(angles);

				cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw) + rand() % (64 - -64 + 1) + -64;
				break; // automatic random
			case 10:
				static float ahs_yaw;

				ahs_yaw += 5;

				if (ahs_yaw > 90) {
					ahs_yaw = -90;
				}

				cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw) + ahs_yaw;
				break; // automatic half spin
			case 11:
				g_EngineClient->GetViewAngles(angles);

				cmd->viewangles.yaw = angles.yaw;
				break; // local view
			case 12:
				static float s_yaw;

				s_yaw += g_Options.anti_aimbot_spin_speed;

				if (s_yaw > 180) {
					s_yaw = -180;
				}

				cmd->viewangles.yaw = s_yaw;
				break; // spin
			case 13:
				g_EngineClient->GetViewAngles(angles);

				cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw);
				break; // lower body
			}

			if (g_Options.anti_aimbot_yaw == 13 && lby_updated(cmd))
				cmd->viewangles.yaw += rand() % (119 - 111 + 1) + 111;
			else
				cmd->viewangles.yaw += g_Options.anti_aimbot_yaw_offset;
		}
	}
	else
	{
		bSendPacket = true;

		switch (g_Options.anti_aimbot_fake_yaw)
		{
		case 0: break; // none
		case 1: cmd->viewangles.yaw -= 180.f; break; // backwards
		case 2: cmd->viewangles.yaw += 90.f; break; // left
		case 3: cmd->viewangles.yaw -= 90.f; break; // right
		case 4: cmd->viewangles.yaw += 90.f + rand() % (64 - -64 + 1) + -64; break; // left random
		case 5: cmd->viewangles.yaw -= 90.f + rand() % (64 - -64 + 1) + -64; break; // right random
		case 6:
			static float lhs_yaw;

			lhs_yaw += 5;

			if (lhs_yaw > 90) {
				lhs_yaw = -90;
			}

			cmd->viewangles.yaw += 90.f + lhs_yaw;
			break; // left half spin
		case 7:
			static float rhs_yaw;

			rhs_yaw += 5;

			if (rhs_yaw > 90) {
				rhs_yaw = -90;
			}

			cmd->viewangles.yaw -= 90.f + rhs_yaw;
			break; // right half spin
		case 8:
			g_EngineClient->GetViewAngles(angles);

			cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw);
			break; // automatic
		case 9:
			g_EngineClient->GetViewAngles(angles);

			cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw) + rand() % (64 - -64 + 1) + -64;
			break; // automatic random
		case 10:
			static float ahs_yaw;

			ahs_yaw += 5;

			if (ahs_yaw > 90) {
				ahs_yaw = -90;
			}

			cmd->viewangles.yaw = GetBestHeadAngle(g_LocalPlayer, angles.yaw) + ahs_yaw;
			break; // automatic half spin
		case 11:
			g_EngineClient->GetViewAngles(angles);

			cmd->viewangles.yaw = angles.yaw;
			break; // local view
		case 12:
			static float s_yaw;

			s_yaw += g_Options.anti_aimbot_spin_speed;

			if (s_yaw > 180) {
				s_yaw = -180;
			}

			cmd->viewangles.yaw = s_yaw;
			break; // spin
		case 13:
			cmd->viewangles.yaw = last_real + 180;
			break; // inverse
		}

		cmd->viewangles.yaw += g_Options.anti_aimbot_fake_yaw_offset;

		choked = -1;
	}

	if ( !bSendPacket )
		last_real = cmd->viewangles.yaw;

	cmd->viewangles.normalize();
}