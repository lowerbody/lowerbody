#include "hooks.hpp"
#include "options.hpp"
#include "menu.hpp"
#include "helpers/input.hpp"
#include "helpers/utils.hpp"
#include "features/bunnyhop.hpp"
#include "features/visuals.hpp"
#include "features/glow.hpp"
#include "helpers/math.hpp"
#include "ragebot.hpp"
#include "antiaimbot.hpp"
#include "clantagspammer.hpp"
#include "spoofedconvar.hpp"
#include "autostrafe.hpp"
#include "hitmarkers.hpp"
#include "weapon_ids.hpp"
#include "pistol.hpp"
#include "rifle.hpp"
#include "shotgun.hpp"
#include "sniper.hpp"
#include "smg.hpp"
#include "nightmode.hpp"
#include "engineprediction.hpp"
#include "eventlogs.hpp"
#include "transparentprops.hpp"
#include "coloredmodels.hpp"
#include "backtracking.hpp"
#include "resolver.hpp"
#include "json.hpp"
#include "configuration.hpp"
#include "itemdefinitions.hpp"
#include "recvproxyhook.hpp"
#include "bullettracers.hpp"

// big number
#define M_PI 3.141592653589793238462643383279502884197169399375105820974944592307816406286208998628034825342117067982148086513282306647093844609550582231725359408128481117450284102701938521105559644622948954930381964428810975665933446128475648233786783165271201909145648566923460348610 

namespace Hooks
{
	vfunc_hook hlclient_hook;
	vfunc_hook direct3d_hook;
	vfunc_hook vguipanel_hook;
	vfunc_hook vguisurf_hook;
	vfunc_hook mdlrender_hook;
	vfunc_hook clientmode_hook;
	vfunc_hook renderview_hook;
	RecvPropHook* sequence_hook;

	vgui::HFont indicator_font;
	vgui::HFont angle_lines_font;
	QAngle real;
	QAngle fake;

	void* render_view_base;

	void Initialize()
	{
		hlclient_hook.setup(g_CHLClient);
		direct3d_hook.setup(g_D3DDevice9);
		vguipanel_hook.setup(g_VGuiPanel);
		vguisurf_hook.setup(g_VGuiSurface);
		mdlrender_hook.setup(g_MdlRender);
		clientmode_hook.setup(g_ClientMode);

		render_view_base = **(void***)((DWORD)Utils::PatternScan(GetModuleHandle(L"client.dll"), "FF 50 14 E8 ? ? ? ? 5D") - 7);
		renderview_hook.setup(render_view_base);

		direct3d_hook.hook_index(index::EndScene, hkEndScene);
		direct3d_hook.hook_index(index::Reset, hkReset);

		hlclient_hook.hook_index(index::FrameStageNotify, hkFrameStageNotify);
		hlclient_hook.hook_index(index::CreateMove, hkCreateMove_Proxy);

		renderview_hook.hook_index(index::RenderView, hkRenderView);

		vguipanel_hook.hook_index(index::PaintTraverse, hkPaintTraverse);

		vguisurf_hook.hook_index(index::PlaySound, hkPlaySound);

		mdlrender_hook.hook_index(index::DrawModelExecute, hkDrawModelExecute);

		clientmode_hook.hook_index(index::DoPostScreenSpaceEffects, hkDoPostScreenEffects);
		clientmode_hook.hook_index(index::OverrideView, hkOverrideView);

		auto sequence_prop = C_BaseViewModel::GetSequenceProp();
		sequence_hook = new RecvPropHook(sequence_prop, hkSequenceProxyFn);

		Visuals::CreateFonts();

		indicator_font = g_VGuiSurface->CreateFont_();
		g_VGuiSurface->SetFontGlyphSet(indicator_font, "Verdana", 30, 650, NULL, NULL, FONTFLAG_ANTIALIAS | FONTFLAG_DROPSHADOW);

		angle_lines_font = g_VGuiSurface->CreateFont_();
		g_VGuiSurface->SetFontGlyphSet(angle_lines_font, "Consolas", 12, 0, NULL, NULL, FONTFLAG_OUTLINE);

		bullettracers::singleton()->initialize();
		hitmarkers::singleton()->initialize();
		nightmode::singleton()->initialize();
		transparentprops::singleton()->initialize();
		eventlogs::singleton()->initialize();
	}
	//--------------------------------------------------------------------------------
	void Shutdown()
	{
		hlclient_hook.unhook_all();
		renderview_hook.unhook_all();
		direct3d_hook.unhook_all();
		vguipanel_hook.unhook_all();
		vguisurf_hook.unhook_all();
		mdlrender_hook.unhook_all();
		clientmode_hook.unhook_all();

		Glow::Get().Shutdown();

		bullettracers::singleton()->uninitialize();
		hitmarkers::singleton()->uninitialize();
		nightmode::singleton()->uninitialize();
		transparentprops::singleton()->uninitialize();
		eventlogs::singleton()->uninitialize();
	}
	//--------------------------------------------------------------------------------
	long __stdcall hkEndScene(IDirect3DDevice9* device)
	{
		auto oEndScene = direct3d_hook.get_original<EndScene>(index::EndScene);

		static bool spoofed = false;
		static ConVar* sv_cheats_var = g_CVar->FindVar("sv_cheats");
		static SpoofedConvar* sv_cheats;

		if (!spoofed)
		{
			if (sv_cheats_var)
			{
				sv_cheats = new SpoofedConvar(sv_cheats_var);
				sv_cheats->SetInt(1);
				spoofed = true;
			}
		}

		Menu::Get().Render();

		if (g_Options.information_rank_revealer && InputSys::Get().IsKeyDown(VK_TAB))
			Utils::RankRevealAll();

		return oEndScene(device);
	}
	//--------------------------------------------------------------------------------
	long __stdcall hkReset(IDirect3DDevice9* device, D3DPRESENT_PARAMETERS* pPresentationParameters)
	{
		auto oReset = direct3d_hook.get_original<Reset>(index::Reset);

		Menu::Get().OnDeviceLost();

		auto hr = oReset(device, pPresentationParameters);

		if (hr >= 0) {
			Menu::Get().OnDeviceReset();
			Visuals::CreateFonts();
		}

		return hr;
	}
	//--------------------------------------------------------------------------------
	void __stdcall hkCreateMove(int sequence_number, float input_sample_frametime, bool active, bool& bSendPacket)
	{
		auto oCreateMove = hlclient_hook.get_original<CreateMove>(index::CreateMove);

		oCreateMove(g_CHLClient, sequence_number, input_sample_frametime, active);

		auto cmd = g_Input->GetUserCmd(sequence_number);
		auto verified = g_Input->GetVerifiedCmd(sequence_number);

		if (!cmd || !cmd->command_number)
			return;

		QAngle old_viewangles;
		float old_forwardmove;
		float old_sidemove;

		if (g_LocalPlayer && g_Options.corrections_fake_yaw_correction)
		{
			for (auto i = 1; i <= g_EngineClient->GetMaxClients(); ++i) {
				auto entity = C_BasePlayer::GetPlayerByIndex(i);

				if (!entity || entity->IsDormant() || !entity->IsAlive() || entity == g_LocalPlayer)
					continue;

				if (i < 65) {
					CResolver::Get().StoreVars(entity);
				}
			}
		}

		nightmode::singleton()->on_createmove();
		transparentprops::singleton()->on_createmove();

		if (g_LocalPlayer)
		{
			if (g_Options.removals_remove_flashbang_effects)
				g_LocalPlayer->m_flFlashMaxAlpha() = 0.f;
			else
				g_LocalPlayer->m_flFlashMaxAlpha() = 255.f;
		}

		if (g_LocalPlayer && g_LocalPlayer->IsAlive() && g_Options.information_third_person)
		{
			if (!*(bool*)((DWORD)g_Input + 0xA5))
			{
				g_EngineClient->ClientCmd_Unrestricted("thirdperson", 0);
			}
		}
		else
		{
			if (*(bool*)((DWORD)g_Input + 0xA5))
			{
				g_EngineClient->ClientCmd_Unrestricted("firstperson", 0);
			}
		}

		static ConVar* developer_var = g_CVar->FindVar("developer");
		static ConVar* con_filter_enable_var = g_CVar->FindVar("con_filter_enable");
		static ConVar* con_filter_text_var = g_CVar->FindVar("con_filter_text");

		if (g_Options.information_event_logs)
		{
			if (developer_var->GetInt() == 0)
				developer_var->SetValue("1");

			if (con_filter_enable_var->GetInt() == 0)
				con_filter_enable_var->SetValue("1");

			if (con_filter_text_var->GetString() != "[lowerbody] ")
				con_filter_text_var->SetValue("[lowerbody] ");
		}
		else if (!g_Options.information_event_logs && developer_var->GetInt() == 1)
		{
			if (developer_var->GetInt() == 1)
				developer_var->SetValue("0");

			if (con_filter_enable_var->GetInt() == 1)
				con_filter_enable_var->SetValue("0");

			if (con_filter_text_var->GetString() == "[lowerbody] ")
				con_filter_text_var->SetValue("");
		}

		if (g_Options.aesthetics_clantag_spammer)
			ClantagSpammer::OnCreateMove(cmd);

		if (g_Options.movement_bunnyhop)
			Bunnyhop::OnCreateMove(cmd);

		if (g_Options.movement_auto_strafe)
			AutoStrafe::OnCreateMove(cmd);

		if (g_Options.exploits_backtrack_moving_targets)
			backtracking->BacktrackPlayer(cmd);

		old_viewangles = cmd->viewangles;
		old_forwardmove = cmd->forwardmove;
		old_sidemove = cmd->sidemove;

		if (g_Options.anti_aimbot_enabled)
			AntiAimbot::OnCreateMove(cmd, bSendPacket);

		if (g_LocalPlayer && g_LocalPlayer->IsAlive())
		{
			if (g_Options.anti_aimbot_enabled)
			{
				if (!bSendPacket)
					real = QAngle(cmd->viewangles.pitch, cmd->viewangles.yaw, 0.f);
				else
					fake = QAngle(cmd->viewangles.pitch, cmd->viewangles.yaw, 0.f);
			}
			else
			{
				g_EngineClient->GetViewAngles(real);
				g_EngineClient->GetViewAngles(fake);
			}
		}

		if (g_LocalPlayer && g_LocalPlayer->IsAlive() && g_LocalPlayer->m_hActiveWeapon())
		{
			EnginePrediction::StartPrediction(cmd);

			if (g_Options.ragebot_enabled)
				Ragebot::OnCreateMove(cmd);

			if (g_Options.pistol_enabled && g_WeaponIDs.IsPistol(g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex()))
				Pistol::OnCreateMove(cmd);

			if (g_Options.shotgun_enabled && g_WeaponIDs.IsShotgun(g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex()))
				Shotgun::OnCreateMove(cmd);

			if (g_Options.smg_enabled && g_WeaponIDs.IsSMG(g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex()))
				SMG::OnCreateMove(cmd);

			if (g_Options.rifle_enabled && g_WeaponIDs.IsRifle(g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex()) || g_WeaponIDs.IsHeavy(g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex()))
				Rifle::OnCreateMove(cmd);

			if (g_Options.sniper_enabled && g_WeaponIDs.IsSniper(g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex()))
				Sniper::OnCreateMove(cmd);

			EnginePrediction::EndPrediction();
		}

		float yaw_delta = cmd->viewangles.yaw - old_viewangles.yaw;
		float f1;
		float f2;

		if (old_viewangles.yaw < 0.f)
			f1 = 360.0f + old_viewangles.yaw;
		else
			f1 = old_viewangles.yaw;

		if (cmd->viewangles.yaw < 0.0f)
			f2 = 360.0f + cmd->viewangles.yaw;
		else
			f2 = cmd->viewangles.yaw;

		if (f2 < f1)
			yaw_delta = abs(f2 - f1);
		else
			yaw_delta = 360.0f - abs(f1 - f2);
		yaw_delta = 360.0f - yaw_delta;

		cmd->forwardmove = cos(DEG2RAD(yaw_delta)) * old_forwardmove + cos(DEG2RAD(yaw_delta + 90.f)) * old_sidemove;
		cmd->sidemove = sin(DEG2RAD(yaw_delta)) * old_forwardmove + sin(DEG2RAD(yaw_delta + 90.f)) * old_sidemove;

		cmd->viewangles.normalize();

		verified->m_cmd = *cmd;
		verified->m_crc = cmd->GetChecksum();
	}
	//--------------------------------------------------------------------------------
	__declspec(naked) void __stdcall hkCreateMove_Proxy(int sequence_number, float input_sample_frametime, bool active)
	{
		__asm
		{
			push ebp
			mov  ebp, esp
			push ebx
			lea  ecx, [esp]
			push ecx
			push dword ptr[active]
			push dword ptr[input_sample_frametime]
			push dword ptr[sequence_number]
			call Hooks::hkCreateMove
			pop  ebx
			pop  ebp
			retn 0Ch
		}
	}
	//--------------------------------------------------------------------------------
	void TexturedPolygon(int n, Vertex_t* vertice, Color col)
	{
		static int texture_id = g_VGuiSurface->CreateNewTextureID(true);
		static unsigned char buf[4] = { 255, 255, 255, 255 };

		g_VGuiSurface->DrawSetTextureRGBA(texture_id, buf, 1, 1);
		g_VGuiSurface->DrawSetColor(col);
		g_VGuiSurface->DrawSetTexture(texture_id);
		g_VGuiSurface->DrawTexturedPolygon(n, vertice);
	}

	void FilledCircle(Vector2D center, Color color, float radius, float points) {
		std::vector<Vertex_t> vertices;
		float step = (float)M_PI * 2.0f / points;

		for (float a = 0; a < (M_PI * 2.0f); a += step)
			vertices.push_back(Vertex_t(Vector2D(radius * cosf(a) + center.x, radius * sinf(a) + center.y)));

		TexturedPolygon((int)points, vertices.data(), color);
	}

	FORCEINLINE float DotProduct(const Vector& a, const Vector& b)
	{
		return (a.x * b.x + a.y * b.y + a.z * b.z);
	}

	inline Vector CrossProduct(Vector& a, Vector& b)
	{
		return Vector(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
	}

	void DirectionArrow(C_BasePlayer* entity)
	{
		constexpr float radius = 360.0f;
		int width, height;

		g_EngineClient->GetScreenSize(width, height);

		Vector origin = entity->m_vecOrigin();

		QAngle angles;
		g_EngineClient->GetViewAngles(angles);

		Vector forward, right, up(0.f, 0.f, 1.f);

		Math::AngleVectors(angles, forward);

		forward.z = 0.0f;
		right = CrossProduct(up, forward);

		float flFront = DotProduct(origin, forward);
		float flSide = DotProduct(origin, right);
		float flXPosition = radius * -flSide;
		float flYPosition = radius * -flFront;

		float rotation = angles.yaw;

		rotation = atan2(flXPosition, flYPosition) + M_PI;
		rotation *= 180.0f / M_PI;

		float flYawRadians = -(rotation)* M_PI / 180.0f;
		float flCosYaw = cos(flYawRadians);
		float flSinYaw = sin(flYawRadians);

		flXPosition = (int) ((width / 2.0f) + (radius * flSinYaw));
		flYPosition = (int) ((height / 2.0f) - (radius * flCosYaw));

		g_VGuiSurface->DrawSetColor(255, 255, 255, entity->m_flVisualsAlpha);
		g_VGuiSurface->DrawOutlinedRect(flXPosition - 1, flYPosition - 1, flXPosition + 1, flYPosition + 1); // todo make triangle
	}

	void __stdcall hkPaintTraverse(vgui::VPANEL panel, bool forceRepaint, bool allowForce)
	{
		static auto panelId = vgui::VPANEL{ 0 };
		static auto zoomId = vgui::VPANEL{ 0 };
		static auto oPaintTraverse = vguipanel_hook.get_original<PaintTraverse>(index::PaintTraverse);

		const auto panelName = g_VGuiPanel->GetName(panel);

		if (g_Options.removals_remove_scope && !strcmp(panelName, "HudZoom") && g_LocalPlayer->m_hActiveWeapon() && g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex() != 8 && g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex() != 39)
			return;

		oPaintTraverse(g_VGuiPanel, panel, forceRepaint, allowForce);

		if (!panelId) {
			const auto panelName = g_VGuiPanel->GetName(panel);
			if (!strcmp(panelName, "FocusOverlayPanel")) {
				panelId = panel;
			}
		}
		else if (panelId == panel) {
			if (g_EngineClient->IsInGame()) {

				if (!g_LocalPlayer)
					return;

				if (g_Options.esp_bounding_box || g_Options.esp_weapon || g_Options.esp_ammo || g_Options.esp_name || g_Options.esp_health || g_Options.esp_flags) {
					for (auto i = 1; i <= g_EngineClient->GetMaxClients(); ++i) {
						auto entity = C_BasePlayer::GetPlayerByIndex(i);

						if (!entity)
							continue;

						if (entity == g_LocalPlayer)
							continue;

						if (i < 65 && entity->IsAlive()) {
							if (entity->IsDormant() && entity->m_flVisualsAlpha > 0)
								entity->m_flVisualsAlpha -= 5;
							else if (entity->m_flVisualsAlpha < 255 && !(entity->IsDormant()))
								entity->m_flVisualsAlpha += 5;

							if (Visuals::Player::Begin(entity)) {
								if (g_Options.esp_bounding_box)     Visuals::Player::RenderBox();
								if (g_Options.esp_weapon) Visuals::Player::RenderWeapon();
								if (g_Options.esp_ammo && entity->m_hActiveWeapon() && !g_WeaponIDs.IsMisc(entity->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex())) Visuals::Player::RenderAmmo();
								if (g_Options.esp_name)     Visuals::Player::RenderName();
								if (g_Options.esp_health)    Visuals::Player::RenderHealth();
								if (g_Options.esp_flags)    Visuals::Player::RenderFlags();
							}

							if (entity->m_iTeamNum() != g_LocalPlayer->m_iTeamNum())
								DirectionArrow(entity);
						}
					}
				}

				hitmarkers::singleton()->on_paint();

				if (g_Options.removals_remove_scope && g_LocalPlayer && g_LocalPlayer->m_bIsScoped() && g_LocalPlayer->m_hActiveWeapon() && g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex() != 8 && g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex() != 39) {
					int w, h;

					g_EngineClient->GetScreenSize(w, h);
					g_VGuiSurface->DrawSetColor(Color::Black);

					int cx = w / 2;
					int cy = h / 2;

					g_VGuiSurface->DrawLine(cx - w, cy, cx + h, cy);
					g_VGuiSurface->DrawLine(cx, cy - w, cx, cy + h);
				}

				if (g_Options.information_indicators && g_LocalPlayer && g_LocalPlayer->IsAlive())
				{
					const wchar_t* buf = L"LBY";
					int w, h;

					g_EngineClient->GetScreenSize(w, h);
					g_VGuiSurface->DrawSetTextFont(indicator_font);

					if (fabsf(real.yaw - g_LocalPlayer->m_flLowerBodyYawTarget()) > 35.f) // fabsf makes a neg a positive
						g_VGuiSurface->DrawSetTextColor(Color(165, 250, 10)); // broke
					else
						g_VGuiSurface->DrawSetTextColor(Color(255, 0, 0)); // tappable aka not broke

					g_VGuiSurface->DrawSetTextPos(8, h - 70);
					g_VGuiSurface->DrawPrintText(buf, wcslen(buf));
				}

				if (g_Options.information_visualize_spread && g_LocalPlayer && g_LocalPlayer->IsAlive())
				{
					int w, h;

					g_EngineClient->GetScreenSize(w, h);

					if (!g_LocalPlayer->m_hActiveWeapon())
						return;

					int cx = w / 2, cy = h / 2;
					float m_flCone = g_LocalPlayer->m_hActiveWeapon()->GetInaccuracy();
					float m_flSpread = g_LocalPlayer->m_hActiveWeapon()->GetSpread();
					float m_flRadius = (m_flCone + m_flSpread) * 500.0f;

					FilledCircle(Vector2D(cx, cy), g_Options.color_visualize_spread, m_flRadius, 60);
				}

				if (g_Options.information_visualize_angles && g_LocalPlayer && g_LocalPlayer->IsAlive())
				{
					Vector src3D, dst3D, forward, src, dst;
					trace_t tr;
					Ray_t ray;
					CTraceFilter filter;
					wchar_t* buf;

					filter.pSkip = g_LocalPlayer;
					Math::AngleVectors(QAngle(0, g_LocalPlayer->m_flLowerBodyYawTarget(), 0), forward);
					src3D = g_LocalPlayer->m_vecOrigin();
					dst3D = src3D + (forward * 50.f);

					ray.Init(src3D, dst3D);

					g_EngineTrace->TraceRay(ray, 0, &filter, &tr);

					if (!Math::WorldToScreen(src3D, src) || !Math::WorldToScreen(tr.endpos, dst))
						return;

					g_VGuiSurface->DrawSetColor(Color(255, 170, 0));
					g_VGuiSurface->DrawLine(src.x, src.y, dst.x, dst.y);

					buf = L"lby";
					g_VGuiSurface->DrawSetTextFont(angle_lines_font);
					g_VGuiSurface->DrawSetTextColor(Color(255, 170, 0));
					g_VGuiSurface->DrawSetTextPos(dst.x, dst.y);
					g_VGuiSurface->DrawPrintText(buf, wcslen(buf));

					Math::AngleVectors(QAngle(0, fake.yaw, 0), forward);
					dst3D = src3D + (forward * 50.f);

					ray.Init(src3D, dst3D);

					g_EngineTrace->TraceRay(ray, 0, &filter, &tr);

					if (!Math::WorldToScreen(src3D, src) || !Math::WorldToScreen(tr.endpos, dst))
						return;

					g_VGuiSurface->DrawSetColor(Color::Green);
					g_VGuiSurface->DrawLine(src.x, src.y, dst.x, dst.y);

					buf = L"fake";
					g_VGuiSurface->DrawSetTextFont(angle_lines_font);
					g_VGuiSurface->DrawSetTextColor(Color::Green);
					g_VGuiSurface->DrawSetTextPos(dst.x, dst.y);
					g_VGuiSurface->DrawPrintText(buf, wcslen(buf));

					Math::AngleVectors(QAngle(0, real.yaw, 0), forward);
					dst3D = src3D + (forward * 50.f);

					ray.Init(src3D, dst3D);

					g_EngineTrace->TraceRay(ray, 0, &filter, &tr);

					if (!Math::WorldToScreen(src3D, src) || !Math::WorldToScreen(tr.endpos, dst))
						return;

					g_VGuiSurface->DrawSetColor(Color::Red);
					g_VGuiSurface->DrawLine(src.x, src.y, dst.x, dst.y);

					buf = L"real";
					g_VGuiSurface->DrawSetTextFont(angle_lines_font);
					g_VGuiSurface->DrawSetTextColor(Color::Red);
					g_VGuiSurface->DrawSetTextPos(dst.x, dst.y);
					g_VGuiSurface->DrawPrintText(buf, wcslen(buf));
				}
			}
		}
	}
	//--------------------------------------------------------------------------------
	void __stdcall hkPlaySound(const char* name)
	{
		static auto oPlaySound = vguisurf_hook.get_original<PlaySound>(index::PlaySound);

		if (g_Options.automation_auto_accept && strstr(name, "UI/competitive_accept_beep.wav")) {
			static auto m_fnAccept = (void(*)())Utils::PatternScan(GetModuleHandleA("client.dll"), "55 8B EC 83 E4 F8 83 EC 08 56 8B 35 ? ? ? ? 57 83 BE");

			m_fnAccept();

			//This will flash the CSGO window on the taskbar
			//so we know a game was found (you cant hear the beep sometimes cause it auto-accepts too fast)
			FLASHWINFO fi;
			fi.cbSize = sizeof(FLASHWINFO);
			fi.hwnd = InputSys::Get().GetMainWindow();
			fi.dwFlags = FLASHW_ALL | FLASHW_TIMERNOFG;
			fi.uCount = 0;
			fi.dwTimeout = 0;
			FlashWindowEx(&fi);
		}

		oPlaySound(g_VGuiSurface, name);
	}
	//--------------------------------------------------------------------------------
	int __stdcall hkDoPostScreenEffects(int a1)
	{
		auto oDoPostScreenEffects = clientmode_hook.get_original<DoPostScreenEffects>(index::DoPostScreenSpaceEffects);

		if (g_LocalPlayer && g_Options.glow_players)
			Glow::Get().Run();

		return oDoPostScreenEffects(g_ClientMode, a1);
	}
	//--------------------------------------------------------------------------------
	std::vector<const char*> smoke_materials = {
		"particle/vistasmokev1/vistasmokev1_smokegrenade",
		"particle/vistasmokev1/vistasmokev1_emods",
		"particle/vistasmokev1/vistasmokev1_emods_impactdust",
		"particle/vistasmokev1/vistasmokev1_fire",
	};

	void __stdcall hkFrameStageNotify(ClientFrameStage_t stage)
	{
		static auto ofunc = hlclient_hook.get_original<FrameStageNotify>(index::FrameStageNotify);

		static QAngle m_oldAimPunchAngle, m_oldViewPunchAngle;

		while (stage == FRAME_NET_UPDATE_POSTDATAUPDATE_START) {
			int localplayer_index = g_EngineClient->GetLocalPlayer();
			C_BasePlayer* localplayer = static_cast<C_BasePlayer*>(g_EntityList->GetClientEntity(localplayer_index));

			if (!localplayer || !localplayer->IsAlive())
				break;

			player_info_t localplayer_info;

			if (!g_EngineClient->GetPlayerInfo(localplayer_index, &localplayer_info))
				break;

			CBaseHandle* weapons = localplayer->m_hMyWeapons();

			if (!weapons)
				continue;

			for (size_t i = 0; weapons[i] != INVALID_EHANDLE_INDEX; i++) {
				C_BaseAttributableItem* weapon = static_cast<C_BaseAttributableItem*>(g_EntityList->GetClientEntityFromHandle(weapons[i]));

				if (!weapon)
					return;

				int32_t item_definition_index = weapon->m_Item().m_iItemDefinitionIndex();

				if (config.HasWeaponConfiguration(item_definition_index)) {
					const EconomyItem_t& weapon_config = config.GetWeaponConfiguration(item_definition_index);

					weapon->m_Item().m_iItemIDHigh() = -1;
					weapon->m_Item().m_iAccountID() = localplayer_info.xuid_low;

					if (weapon_config.item_definition_index != 0) {
						if (ItemDefinitionIndex.find(weapon_config.item_definition_index) != ItemDefinitionIndex.end()) {
							weapon->m_nModelIndex() = g_MdlInfo->GetModelIndex(ItemDefinitionIndex.at(weapon_config.item_definition_index).model);

							if (ItemDefinitionIndex.find(item_definition_index) != ItemDefinitionIndex.end()) {
								weapon->m_Item().m_iItemDefinitionIndex() = weapon_config.item_definition_index;
							}
						}
					}

					if (weapon_config.fallback_paint_kit != 0)
						weapon->m_nFallbackPaintKit() = weapon_config.fallback_paint_kit;

					if (weapon_config.fallback_seed != 0)
						weapon->m_nFallbackSeed() = weapon_config.fallback_seed;

					if (weapon_config.entity_quality != 0)
						weapon->m_Item().m_iEntityQuality() = weapon_config.entity_quality;

					if (weapon_config.fallback_wear != 0)
						weapon->m_flFallbackWear() = weapon_config.fallback_wear;
				}
			}

			CBaseHandle viewmodel_handle = localplayer->m_hViewModel();

			if (viewmodel_handle == INVALID_EHANDLE_INDEX)
				break;

			C_BaseViewModel* viewmodel = static_cast<C_BaseViewModel*>(g_EntityList->GetClientEntityFromHandle(viewmodel_handle));

			if (!viewmodel)
				break;

			CBaseHandle viewmodel_weapon_handle = viewmodel->m_hWeapon();

			if (viewmodel_weapon_handle == INVALID_EHANDLE_INDEX)
				break;

			C_BaseAttributableItem* viewmodel_weapon = static_cast<C_BaseAttributableItem*>(g_EntityList->GetClientEntityFromHandle(viewmodel_weapon_handle));

			if (!viewmodel_weapon)
				break;

			if (ItemDefinitionIndex.find(viewmodel_weapon->m_Item().m_iItemDefinitionIndex()) != ItemDefinitionIndex.end()) {
				const Item_t& override_weapon = ItemDefinitionIndex.at(viewmodel_weapon->m_Item().m_iItemDefinitionIndex());
				viewmodel->m_nModelIndex() = g_MdlInfo->GetModelIndex(override_weapon.model);
				viewmodel->m_nViewModelIndex() = g_MdlInfo->GetModelIndex(override_weapon.model);
			}

			break;
		}

		if (g_LocalPlayer) {
			if (stage == FRAME_NET_UPDATE_POSTDATAUPDATE_START) {
				if (g_Options.corrections_fake_yaw_correction)
				{
					for (auto i = 1; i <= g_EngineClient->GetMaxClients(); ++i) {
						auto entity = C_BasePlayer::GetPlayerByIndex(i);

						if (!entity || entity->IsDormant() || !entity->IsAlive() || entity == g_LocalPlayer)
							continue;

						if (i < 65) {
							CResolver::Get().Resolve(entity);
						}
					}
				}
			}

			if (stage == FRAME_RENDER_START) {
				if (g_LocalPlayer->IsAlive())
				{
					IClientEntity *pLocal = g_EntityList->GetClientEntity(g_EngineClient->GetLocalPlayer());

					if (g_Options.information_third_person && pLocal)
						*(QAngle*)((DWORD)pLocal + 0x31C8) = real;
				}

				for (auto material_name : smoke_materials)
				{
					static auto m_fnLineGoesThruSmoke = Utils::PatternScan(GetModuleHandleW(L"client.dll"), "55 8B EC 83 EC 08 8B 15 ? ? ? ? 0F 57 C0");
					static auto m_iSmokeCount = *(DWORD*)(m_fnLineGoesThruSmoke + 0x8);

					IMaterial* material = g_MatSystem->FindMaterial(material_name, TEXTURE_GROUP_OTHER);
					material->SetMaterialVarFlag(MATERIAL_VAR_NO_DRAW, g_Options.removals_remove_smoke_grenades);

					*(int*)(m_iSmokeCount) = 0;
				}
			}

			if (g_Options.removals_remove_visual_recoil)
			{
				m_oldAimPunchAngle = g_LocalPlayer->m_aimPunchAngle();
				m_oldViewPunchAngle = g_LocalPlayer->m_viewPunchAngle();

				g_LocalPlayer->m_aimPunchAngle() = QAngle{ 0.f, 0.f, 0.f };
				g_LocalPlayer->m_viewPunchAngle() = QAngle{ 0.f, 0.f, 0.f };
			}
		}

		ofunc(g_CHLClient, stage);

		if (g_Options.removals_remove_visual_recoil && g_LocalPlayer && g_LocalPlayer->IsAlive())
		{
			g_LocalPlayer->m_aimPunchAngle() = m_oldAimPunchAngle;
			g_LocalPlayer->m_viewPunchAngle() = m_oldViewPunchAngle;
		}
	}
	//--------------------------------------------------------------------------------
	void __stdcall hkDrawModelExecute(IMatRenderContext* ctx, const DrawModelState_t& state, const ModelRenderInfo_t& pInfo, matrix3x4_t* pCustomBoneToWorld)
	{
		static auto ofunc = mdlrender_hook.get_original<DrawModelExecute>(index::DrawModelExecute);

		const auto mdl = pInfo.pModel;

		ColoredModels::Get().OnDrawModelExecute(ctx, state, pInfo, pCustomBoneToWorld);

		if (strstr(mdl->szName, "models/player") != nullptr)
		{
			auto ent = C_BasePlayer::GetPlayerByIndex(pInfo.entity_index);

			if (g_LocalPlayer && ent)
				if (g_LocalPlayer->IsAlive() && g_LocalPlayer->m_bIsScoped() && ent == C_BasePlayer::GetPlayerByIndex(g_LocalPlayer->EntIndex()))
					if (g_Options.information_third_person)
						if (g_RenderView->GetBlend() != 0.3f)
							g_RenderView->SetBlend(0.3f);
						else
							if (g_RenderView->GetBlend() != 1.f)
								g_RenderView->SetBlend(1.f);
		}

		ofunc(g_MdlRender, ctx, state, pInfo, pCustomBoneToWorld);

		g_MdlRender->ForcedMaterialOverride(nullptr);
	}
	//--------------------------------------------------------------------------------
	void __stdcall hkOverrideView(CViewSetup* pViewSetup)
	{
		static auto oOverrideView = clientmode_hook.get_original<OverrideView>(index::OverrideView);

		oOverrideView(pViewSetup);
	}
	//--------------------------------------------------------------------------------
	void __fastcall hkRenderView(void* thisptr, void*, CViewSetup &setup, CViewSetup &hudViewSetup, unsigned int nClearFlags, int whatToDraw)
	{
		static auto oRenderView = renderview_hook.get_original<RenderView>(index::RenderView);

		if (g_Options.aesthetics_bullet_tracers)
			bullettracers::singleton()->on_render_view();

		oRenderView(thisptr, setup, hudViewSetup, nClearFlags, whatToDraw);
	}
}
