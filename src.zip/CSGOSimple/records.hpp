#pragma once

#include "valve_sdk\csgostructs.hpp"
#include "valve_sdk\sdk.hpp"

#include <deque>
#include <algorithm>
#include <array>
#include <tuple>

struct CTickRecord;

struct CValidTick {
	explicit operator CTickRecord() const;

	explicit operator bool() const noexcept {
		return m_flSimulationTime > 0.f;
	}

	float m_flPitch = 0.f;
	float m_flYaw = 0.f;
	float m_flSimulationTime = 0.f;
	C_BasePlayer* m_pEntity = nullptr;
};

struct CTickRecord {
	CTickRecord() {}
	CTickRecord(C_BasePlayer* ent) {
		m_flLowerBodyYawTarget = ent->m_flLowerBodyYawTarget();
		m_angEyeAngles = ent->m_angEyeAngles();
		m_flSimulationTime = ent->m_flSimulationTime();
		m_vecOrigin = ent->m_vecOrigin();
		m_vecVelocity = ent->m_vecVelocity();
		tickcount = 0;
	}

	explicit operator bool() const noexcept {
		return m_flSimulationTime > 0.f;
	}

	bool operator>(const CTickRecord& others) {
		return (m_flSimulationTime > others.m_flSimulationTime);
	}
	bool operator>=(const CTickRecord& others) {
		return (m_flSimulationTime >= others.m_flSimulationTime);
	}
	bool operator<(const CTickRecord& others) {
		return (m_flSimulationTime < others.m_flSimulationTime);
	}
	bool operator<=(const CTickRecord& others) {
		return (m_flSimulationTime <= others.m_flSimulationTime);
	}
	bool operator==(const CTickRecord& others) {
		return (m_flSimulationTime == others.m_flSimulationTime);
	}

	float m_flLowerBodyYawTarget = 0.f;
	QAngle m_angEyeAngles = QAngle(0, 0, 0);
	float m_flSimulationTime = 0.f;
	Vector m_vecOrigin = Vector(0, 0, 0);
	Vector m_vecVelocity = Vector(0, 0, 0);
	CValidTick validtick;
	int tickcount = 0;
};

inline CValidTick::operator CTickRecord() const {
	CTickRecord rec(m_pEntity);
	rec.m_angEyeAngles.pitch = this->m_flPitch;
	rec.m_angEyeAngles.yaw = this->m_flYaw;
	rec.m_flSimulationTime = this->m_flSimulationTime;
	return rec;
}