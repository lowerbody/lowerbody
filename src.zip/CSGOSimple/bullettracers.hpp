#include "valve_sdk\csgostructs.hpp"
#include "hooks.hpp"
#include "helpers/utils.hpp"
#include "options.hpp"

#include "IViewRenderBeams.hpp"

class bullettracers
{
	class player_hurt_listener : public IGameEventListener2
	{
	public:
		void start()
		{
			g_GameEvents->AddListener(this, "bullet_impact", false);
		}

		void stop()
		{
			g_GameEvents->RemoveListener(this);
		}

		void FireGameEvent(IGameEvent *event) override
		{
			bullettracers::singleton()->on_fire_event(event);
		}

		int GetEventDebugID(void) override
		{
			return EVENT_DEBUG_ID_INIT /*0x2A*/;
		}
	};
public:
	static bullettracers* singleton()
	{
		static bullettracers* instance = new bullettracers;
		return instance;
	}

	void initialize()
	{
		_listener.start();
	}

	void uninitialize()
	{
		_listener.stop();
	}

	std::vector<BeamInfo_t> render_queue;

	void on_fire_event(IGameEvent* event)
	{
		if (!strcmp(event->GetName(), "bullet_impact"))
		{
			C_BasePlayer* shooter = (C_BasePlayer*)g_EntityList->GetClientEntity(g_EngineClient->GetPlayerForUserID(event->GetInt("userid")));

			if (shooter == g_LocalPlayer)
			{
				if (g_Options.aesthetics_bullet_tracers)
				{
					Vector impact(event->GetFloat("x"), event->GetFloat("y"), event->GetFloat("z"));

					BeamInfo_t beamInfo;
					beamInfo.m_vecStart = g_LocalPlayer->GetEyePos();
					beamInfo.m_vecEnd = impact;
					beamInfo.m_nType = 0x00; // TE_BEAMPOINTS
					beamInfo.m_pszModelName = "sprites/physbeam.vmt";
					beamInfo.m_nModelIndex = -1; // will be set by CreateBeamPoints if its -1
					beamInfo.m_flHaloScale = 0.0f;
					beamInfo.m_flLife = 1.f;
					beamInfo.m_flWidth = 2.0f;
					beamInfo.m_flEndWidth = 2.0f;
					beamInfo.m_flFadeLength = 0.0f;
					beamInfo.m_flAmplitude = 2.0f;
					beamInfo.m_flBrightness = 255.f;
					beamInfo.m_flSpeed = 0.2f;
					beamInfo.m_nStartFrame = 0;
					beamInfo.m_flFrameRate = 0.f;
					beamInfo.m_flRed = g_Options.color_bullet_tracers.r();
					beamInfo.m_flGreen = g_Options.color_bullet_tracers.g();
					beamInfo.m_flBlue = g_Options.color_bullet_tracers.b();
					beamInfo.m_nSegments = 2;
					beamInfo.m_bRenderable = true;
					beamInfo.m_nFlags = FBEAM_ONLYNOISEONCE | FBEAM_NOTILE | FBEAM_HALOBEAM;

					render_queue.push_back( beamInfo );
				}
			}
		}
	}

	void on_render_view()
	{
		if ( !g_EngineClient->IsInGame( ) || !g_LocalPlayer )
			return;

		if ( render_queue.size( ) > 30 )
			render_queue.pop_back( );

		for ( int i = 0; i < render_queue.size( ); i++ )
		{
			auto beamInfo = render_queue.at( i );
			g_ViewRenderBeams->DrawBeam( g_ViewRenderBeams->CreateBeamPoints( beamInfo ) );
		}

		render_queue.clear( );
	}
private:
	player_hurt_listener    _listener;
};