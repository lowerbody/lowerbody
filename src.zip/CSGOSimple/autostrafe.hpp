#pragma once

#include "valve_sdk/csgostructs.hpp"

class C_BasePlayer;
class CUserCmd;

namespace AutoStrafe
{
	void OnCreateMove(CUserCmd* cmd);
}