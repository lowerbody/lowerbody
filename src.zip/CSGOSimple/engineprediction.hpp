#include "valve_sdk\csgostructs.hpp"
#include "valve_sdk\sdk.hpp"

#include "helpers\utils.hpp"

class C_BasePlayer;
class CUserCmd;

namespace EnginePrediction
{
	void StartPrediction(CUserCmd* cmd);
	void EndPrediction();
}