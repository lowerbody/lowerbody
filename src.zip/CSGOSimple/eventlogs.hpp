#include "valve_sdk\csgostructs.hpp"
#include "hooks.hpp"
#include "helpers/utils.hpp"
#include "options.hpp"

class eventlogs
{
	class player_hurt_listener : public IGameEventListener2
	{
	public:
		void start()
		{
			g_GameEvents->AddListener(this, "player_hurt", false);
			g_GameEvents->AddListener(this, "item_purchase", false);
		}

		void stop()
		{
			g_GameEvents->RemoveListener(this);
		}

		void FireGameEvent(IGameEvent *event) override
		{
			eventlogs::singleton()->on_fire_event(event);
		}

		int GetEventDebugID(void) override
		{
			return EVENT_DEBUG_ID_INIT /*0x2A*/;
		}
	};
public:
	static eventlogs* singleton()
	{
		static eventlogs* instance = new eventlogs;
		return instance;
	}

	void initialize()
	{
		_listener.start();
	}

	void uninitialize()
	{
		_listener.stop();
	}

	void on_fire_event(IGameEvent* event)
	{
		if (!g_LocalPlayer)
			return;

		if (!strcmp(event->GetName(), "player_hurt")) {
			C_BasePlayer* hurt = (C_BasePlayer*)g_EntityList->GetClientEntity(g_EngineClient->GetPlayerForUserID(event->GetInt("userid")));
			C_BasePlayer* attacker = (C_BasePlayer*)g_EntityList->GetClientEntity(g_EngineClient->GetPlayerForUserID(event->GetInt("attacker")));

			if (hurt != g_LocalPlayer && attacker == g_LocalPlayer)
			{
				if (g_Options.information_event_logs)
				{
					std::stringstream stream;
					stream << "[lowerbody] Hit " << hurt->GetPlayerInfo().szName << " for " << event->GetString("dmg_health") << " damage (" << event->GetString("health") << " health remaining)\n";
					Utils::WriteToConsole(stream.str().c_str());
				}
			}
		}

		if (!strcmp(event->GetName(), "item_purchase")) {
			C_BasePlayer* player = (C_BasePlayer*)g_EntityList->GetClientEntity(g_EngineClient->GetPlayerForUserID(event->GetInt("userid")));

			if (player != g_LocalPlayer)
			{
				if (g_Options.information_event_logs)
				{
					std::stringstream stream;
					stream << "[lowerbody] " << player->GetPlayerInfo().szName << " bought " << event->GetString("weapon") << "\n";
					Utils::WriteToConsole(stream.str().c_str());
				}
			}
		}
	}
private:
	player_hurt_listener    _listener;
};