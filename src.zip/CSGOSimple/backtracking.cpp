#include "backtracking.hpp"
#include "helpers/math.hpp"
#include "options.hpp"

#define TICK_INTERVAL			(g_GlobalVars->interval_per_tick)

void Backtracking::BacktrackPlayer(CUserCmd* cmd)
{
	int m_iBestTargetIndex = -1;
	float m_flBestFOV = FLT_MAX;

	player_info_t info;

	if (!g_LocalPlayer || !g_LocalPlayer->IsAlive() || !g_EngineClient || !g_EngineClient->IsConnected() || !g_EngineClient->IsInGame())
		return;

	for (int i = 0; i < g_EngineClient->GetMaxClients(); i++)
	{
		C_BasePlayer* entity = static_cast<C_BasePlayer*>(g_EntityList->GetClientEntity(i));

		if (!entity)
			continue;

		if (entity == g_LocalPlayer)
			continue;

		if (!g_EngineClient->GetPlayerInfo(i, &info))
			continue;

		if (!entity->IsAlive())
			continue;

		if (entity->IsDormant())
			continue;

		if (entity->m_iTeamNum() == g_LocalPlayer->m_iTeamNum())
			continue;

		float m_flSimulationTime = entity->m_flSimulationTime();
		Vector m_vectorHitboxZero = entity->GetHitboxPos(0);

		positions[i][cmd->command_number % 13] = BacktrackingData{ m_flSimulationTime, m_vectorHitboxZero };

		Vector m_vectorViewDirection = angle_vector(cmd->viewangles + (g_LocalPlayer->m_aimPunchAngle() * 2.f));
		float m_flFOVDistance = distance_point_to_line(m_vectorHitboxZero, g_LocalPlayer->GetEyePos(), m_vectorViewDirection);

		if (m_flBestFOV > m_flFOVDistance)
		{
			m_flBestFOV = m_flFOVDistance;
			m_iBestTargetIndex = i;
		}
	}

	float m_flBestTargetSimulationTime;

	if (m_iBestTargetIndex != -1)
	{
		float m_flTemporary = FLT_MAX;
		Vector m_vectorViewDirection = angle_vector(cmd->viewangles + (g_LocalPlayer->m_aimPunchAngle() * 2.f));

		for (int t = 0; t < g_Options.exploits_backtrack_ticks; ++t) // 12?
		{
			float m_flTemporaryDistance = distance_point_to_line(positions[m_iBestTargetIndex][t].m_vectorHitboxPos, g_LocalPlayer->GetEyePos(), m_vectorViewDirection);
			if (m_flTemporary > m_flTemporaryDistance && positions[m_iBestTargetIndex][t].m_flSimulationTime > g_LocalPlayer->m_flSimulationTime() - 1)
			{
				m_flTemporary = m_flTemporaryDistance;
				m_flBestTargetSimulationTime = positions[m_iBestTargetIndex][t].m_flSimulationTime;
			}
		}

		cmd->tick_count = TIME_TO_TICKS(m_flBestTargetSimulationTime); // reset the tick count this is what causes you to "lag" this is how you make the server think your
		// lagging
	}
}

Backtracking* backtracking = new Backtracking();
BacktrackingData positions[64][12];