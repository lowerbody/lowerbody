#pragma once

#include "valve_sdk\math\Vector.hpp"
#include "valve_sdk\csgostructs.hpp"
#include "valve_sdk\interfaces\IEngineTrace.hpp"

namespace Autowall
{
	void TraceLine(Vector& absStart, Vector& absEnd, unsigned int mask, C_BaseEntity* ignore, CGameTrace* ptr);

	void ClipTraceToPlayers(Vector& absStart, Vector absEnd, unsigned int mask, ITraceFilter* filter, CGameTrace* tr);

	void GetBulletTypeParameters(float& maxRange, float& maxDistance, char* bulletType, bool sv_penetration_type);

	bool IsBreakableEntity( C_BaseEntity* entity);

	void ScaleDamage(CGameTrace &enterTrace, CCSWeaponInfo *weaponData, float& currentDamage);

	bool TraceToExit(CGameTrace& enterTrace, CGameTrace& exitTrace, Vector startPosition, Vector direction);

	bool HandleBulletPenetration(CCSWeaponInfo* weaponData, CGameTrace& enterTrace, Vector& eyePosition, Vector direction, int& possibleHitsRemaining, float& currentDamage, float penetrationPower, bool sv_penetration_type, float ff_damage_reduction_bullets, float ff_damage_bullet_penetration);

	bool FireBullet(C_BaseCombatWeapon* pWeapon, Vector& direction, float& currentDamage);

	float CanHit(Vector &vecEyePos, Vector &point);
}