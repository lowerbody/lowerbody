#pragma once

#include "valve_sdk/csgostructs.hpp"

#define M_PI 3.141592653589793238462643383279502884197169399375105820974944592307816406286208998628034825342117067982148086513282306647093844609550582231725359408128481117450284102701938521105559644622948954930381964428810975665933446128475648233786783165271201909145648566923460348610

class Backtracking
{
	int m_iLatestTick;
public:
	void BacktrackPlayer(CUserCmd* cmd);
};

struct BacktrackingData
{
	float m_flSimulationTime;
	Vector m_vectorHitboxPos;
};

inline Vector angle_vector(QAngle angle)
{
	auto sy = sin(angle.yaw / 180.f * static_cast<float>(M_PI));
	auto cy = cos(angle.yaw / 180.f * static_cast<float>(M_PI));

	auto sp = sin(angle.pitch / 180.f * static_cast<float>(M_PI));
	auto cp = cos(angle.pitch / 180.f* static_cast<float>(M_PI));

	return Vector(cp * cy, cp* sy, -sp);
}

inline float distance_point_to_line(Vector point, Vector lineOrigin, Vector direction)
{
	auto pointDirection = point - lineOrigin;

	auto temporaryOffset = pointDirection.Dot(direction) / (direction.x * direction.x + direction.y * direction.y + direction.z * direction.z);

	if (temporaryOffset < 0.000001f)
		return FLT_MAX;

	auto perpendicularPoint = lineOrigin + (direction * temporaryOffset);

	return (point - perpendicularPoint).Length();
}

extern Backtracking* backtracking;
extern BacktrackingData positions[64][12];