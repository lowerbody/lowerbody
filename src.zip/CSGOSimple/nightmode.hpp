#include "valve_sdk\csgostructs.hpp"

#include "hooks.hpp"
#include "helpers/utils.hpp"
#include "options.hpp"

bool preformed_color_modulate = false;

class nightmode
{
	class game_newmap_listener : public IGameEventListener2
	{
	public:
		void start()
		{
			g_GameEvents->AddListener(this, "game_newmap", false);
		}

		void stop()
		{
			g_GameEvents->RemoveListener(this);
		}

		void FireGameEvent(IGameEvent *event) override
		{
			nightmode::singleton()->on_fire_event(event);
		}

		int GetEventDebugID(void) override
		{
			return EVENT_DEBUG_ID_INIT /*0x2A*/;
		}
	};
public:
	static nightmode* singleton()
	{
		static nightmode* instance = new nightmode;
		return instance;
	}

	void initialize()
	{
		_listener.start();
	}

	void uninitialize()
	{
		_listener.stop();
	}

	void on_fire_event(IGameEvent* event)
	{
		if (!strcmp(event->GetName(), "game_newmap")) {
			preformed_color_modulate = false;
		}
	}

	void on_createmove()
	{
		if (!g_LocalPlayer || !g_EngineClient->IsConnected() || !g_EngineClient->IsInGame())
			return;

		if (g_Options.aesthetics_night_mode)
		{
			if (!preformed_color_modulate)
			{
				for (MaterialHandle_t i = g_MatSystem->FirstMaterial(); i != g_MatSystem->InvalidMaterial(); i = g_MatSystem->NextMaterial(i))
				{
					IMaterial* material = g_MatSystem->GetMaterial(i);

					if (!material || material->IsErrorMaterial())
						continue;

					if (strstr(material->GetTextureGroupName(), "World"))
						material->ColorModulate(0.15f, 0.15f, 0.15f);

					if (strstr(material->GetTextureGroupName(), "Model"))
						material->ColorModulate(0.6f, 0.6f, 0.6f);

					if (strstr(material->GetTextureGroupName(), "StaticProp"))
						material->ColorModulate(0.3f, 0.3f, 0.3f);

					if (strstr(material->GetTextureGroupName(), "SkyBox"))
						material->ColorModulate(0.23f, 0.22f, 0.22f);

					preformed_color_modulate = true;
				}
			}
		}
		else
		{
			if (preformed_color_modulate)
			{
				for (MaterialHandle_t i = g_MatSystem->FirstMaterial(); i != g_MatSystem->InvalidMaterial(); i = g_MatSystem->NextMaterial(i))
				{
					IMaterial* material = g_MatSystem->GetMaterial(i);

					if (!material || material->IsErrorMaterial())
						continue;

					if (strstr(material->GetTextureGroupName(), "World") || strstr(material->GetTextureGroupName(), "Model") || strstr(material->GetTextureGroupName(), "StaticProp") || strstr(material->GetTextureGroupName(), "SkyBox"))
						material->ColorModulate(1.f, 1.f, 1.f);

					preformed_color_modulate = false;
				}
			}
		}
	}
private:
	game_newmap_listener    _listener;
};