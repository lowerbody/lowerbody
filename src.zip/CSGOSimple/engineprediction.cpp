#include "engineprediction.hpp"

CMoveData m_MoveData;
float m_flOldCurtime;
float m_flOldFrametime;

int* m_pPredictionRandomSeed;

void EnginePrediction::StartPrediction(CUserCmd* cmd) {
	static bool bInit = false;

	if (!bInit) {
		m_pPredictionRandomSeed = *(int**)(Utils::PatternScan(GetModuleHandleW(L"client.dll"), "8B 0D ? ? ? ? BA ? ? ? ? E8 ? ? ? ? 83 C4 04") + 2);
		bInit = true;
	}

	*m_pPredictionRandomSeed = cmd->random_seed;

	m_flOldCurtime = g_GlobalVars->curtime;
	m_flOldFrametime = g_GlobalVars->frametime;

	g_GlobalVars->curtime = g_LocalPlayer->m_nTickBase() * g_GlobalVars->interval_per_tick;
	g_GlobalVars->frametime = g_GlobalVars->interval_per_tick;

	g_GameMovement->StartTrackPredictionErrors(g_LocalPlayer);

	memset(&m_MoveData, 0, sizeof(m_MoveData));

	g_MoveHelper->SetHost(g_LocalPlayer);
	g_Prediction->SetupMove(g_LocalPlayer, cmd, g_MoveHelper, &m_MoveData);
	g_GameMovement->ProcessMovement(g_LocalPlayer, &m_MoveData);
	g_Prediction->FinishMove(g_LocalPlayer, cmd, &m_MoveData);
}

void EnginePrediction::EndPrediction() {
	g_GameMovement->FinishTrackPredictionErrors(g_LocalPlayer);
	g_MoveHelper->SetHost(0);

	*m_pPredictionRandomSeed = -1;

	g_GlobalVars->curtime = m_flOldCurtime;
	g_GlobalVars->frametime = m_flOldFrametime;
}